import { E, c, m, p, a, s } from "./2.BS1fgMUm.js";
export {
  E as Embed,
  c as create_components,
  m as mount_css,
  p as prefix_css,
  a as process_langs,
  s as setupi18n
};
