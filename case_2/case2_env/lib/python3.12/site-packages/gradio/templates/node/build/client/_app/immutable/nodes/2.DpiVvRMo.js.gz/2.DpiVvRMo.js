import { z, _ } from "../chunks/2.BS1fgMUm.js";
export {
  z as component,
  _ as universal
};
